from scipy import io
import numpy as np
import os

if __name__ == '__main__':
    save_dir = '/HDDs/hdd1/gyy/dmha/dicts_1'
    input_ls = ['train_wloc_real.npy', 'test_wloc_real.npy']
    for input_npy in input_ls:
        mat = np.load(os.path.join(save_dir, input_npy), allow_pickle=True).item()
        mat = [{'top': mat[i]['dets_top_ori'], 'hor': mat[i]['dets_hor_ori'], 'id': mat[i]['frame']} for i in mat]
        io.savemat(os.path.join(save_dir, input_npy[:-4] + '.mat'), {'box': mat})