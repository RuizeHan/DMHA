import sys
CENTERNET_PATH = 'lib/'
sys.path.insert(0, CENTERNET_PATH)

from detectors.detector_factory import detector_factory
from opts import opts

MODEL_PATH = '../exp/ctdet/coco_dla/model_hor_last.pth'
TASK = 'ctdet' # or 'multi_pose' for human pose estimation
opt = opts().init('{} --load_model {}'.format(TASK, MODEL_PATH).split(' '))
detector = detector_factory[opt.task](opt)

img = '/HDDs/hdd1/gyy/dmha/virtual_data/v_s1_h1/images/992.png'
detection = detector.run(img)['results']
heatmap = detector.run(img)['hm']
a = 1