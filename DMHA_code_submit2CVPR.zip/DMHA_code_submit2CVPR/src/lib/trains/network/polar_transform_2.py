import numpy as np
# from scipy.misc import imread, imsave
import os
import cv2
import torch
import torch.nn as nn

class PolarTransform(nn.Module):
    def __init__(self):
        super(PolarTransform, self).__init__()


    def sample_within_bounds(self, signal, x, y, bounds, b, c):
        xmin, xmax, ymin, ymax = bounds

        mask = (xmin <= x) & (x < xmax) & (ymin <= y) & (y < ymax)
        mask = torch.ByteTensor(mask)
        x = torch.LongTensor(x)
        y = torch.LongTensor(y)
        sample = torch.zeros(x.shape).cuda()
        sample[mask] = signal[b[mask], c[mask], x[mask], y[mask]]
        # sample = signal[:, :, x, y]
        # signal = torch.gather(signal, 2, torch.tensor(x))
        # signal = torch.gather(signal, 3, torch.tensor(y))
        # sample = signal[:, :, x, y]

        return sample

    def sample_bilinear(self, signal, rx, ry, rb, rc):
        signal_dim_x = signal.shape[2]
        signal_dim_y = signal.shape[3]


        # obtain four sample coordinates
        ix0 = rx.astype(int)
        iy0 = ry.astype(int)
        ix1 = ix0 + 1
        iy1 = iy0 + 1

        bounds = (0, signal_dim_x, 0, signal_dim_y)

        # sample signal at each four positions
        signal_00 = self.sample_within_bounds(signal, ix0, iy0, bounds, rb, rc)
        signal_10 = self.sample_within_bounds(signal, ix1, iy0, bounds, rb, rc)
        signal_01 = self.sample_within_bounds(signal, ix0, iy1, bounds, rb, rc)
        signal_11 = self.sample_within_bounds(signal, ix1, iy1, bounds, rb, rc)

        # linear interpolation in x-direction
        fx1 = (ix1 - rx) * signal_00 + (rx - ix0) * signal_10
        fx2 = (ix1 - rx) * signal_01 + (rx - ix0) * signal_11

        # linear interpolation in y-direction
        f = (iy1 - ry) * fx1 + (ry - iy0) * fx2
        return f

    def forward(self, input, ctr):
        ############################ Apply Polar Transform to Aerial Images in CVUSA Dataset #############################

        ctr_x, ctr_y = ctr[:, 1].numpy(), ctr[:, 0].numpy()
        ctr_x = np.expand_dims(ctr_x, -1)
        ctr_x = np.expand_dims(ctr_x, -1)
        ctr_x = np.expand_dims(ctr_x, -1)
        ctr_y = np.expand_dims(ctr_y, -1)
        ctr_y = np.expand_dims(ctr_y, -1)
        ctr_y = np.expand_dims(ctr_y, -1)
        input_size_w, input_size_h = input.shape[2], input.shape[3]
        output_size_w, output_size_h = input_size_w * 4, input_size_h

        i = np.arange(0, output_size_h)
        j = np.arange(0, output_size_w)
        k = np.arange(0, ctr.shape[0])
        c = np.arange(0, 1)
        cc, kk, ii, jj = np.meshgrid(c, k, i, j)

        y = ctr_x - input_size_w / 2. / input_size_h * (input_size_h - 1 - ii) * np.sin(2 * np.pi * jj / input_size_w)
        x = ctr_y + input_size_h / 2. / input_size_h * (input_size_h - 1 - ii) * np.cos(2 * np.pi * jj / input_size_w)
        bs = torch.LongTensor(kk)
        c = torch.LongTensor(cc)

        image = self.sample_bilinear(input, x, y, bs, c)
            # cv2.imwrite(output_dir + img.replace('.jpg', '.png'), image)

        return image