from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '2'

import torch
import torch.utils.data
from opts import opts
from models.model import create_model, load_model, save_model
from models.data_parallel import DataParallel
from logger import Logger
from datasets.dataset_factory import get_dataset
from trains.train_factory import train_factory
from itertools import chain
import warnings
# warnings.filterwarnings("ignore")
from torch.utils.tensorboard import SummaryWriter
# tensorboard --logdir=runs

def main(opt):
  torch.manual_seed(opt.seed)
  torch.backends.cudnn.benchmark = not opt.not_cuda_benchmark and not opt.test
  Dataset = get_dataset('dhn', 'dhn')
  print(opt)

  # os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpus_str
  opt.device = torch.device('cuda' if opt.gpus[0] >= 0 else 'cpu')
  

  # Inference
  print('Setting up data...')
  val_loader = torch.utils.data.DataLoader(
      Dataset(opt, 'test'),
      batch_size=1, 
      shuffle=False,
      num_workers=0,
      pin_memory=True
  )

  if opt.test:
    if opt.result_path!='':
      preds=torch.load(opt.result_path)
    else:
      print('No GPU, no model and no saved results? ARE YOU KIDDING ME?')
      exit(0)
    val_loader.dataset.run_eval(preds, opt.save_dir)
    return

if __name__ == '__main__':
  opt = opts().parse()
  # opt.init('{} --batch_size {} --arch {}'.format('dhn',1, 'DHN'))
  main(opt)