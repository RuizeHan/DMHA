import numpy as np
# from scipy.misc import imread, imsave
import os
import cv2
import torch
import torch.nn as nn

class PolarTransform(nn.Module):
    def __init__(self):
        super(PolarTransform, self).__init__()


    def sample_within_bounds(self, signal, x, y, bounds, b, c):
        xmin, xmax, ymin, ymax = bounds

        mask = (xmin <= x) & (x < xmax) & (ymin <= y) & (y < ymax)
        mask = torch.as_tensor(mask, dtype=torch.bool)
        # mask = torch.ByteTensor(mask)
        # x = torch.LongTensor(x)
        # y = torch.LongTensor(y)
        sample = torch.zeros(x.shape).cuda()
        sample[mask] = signal[b[mask], c[mask], x[mask], y[mask]]
        # sample = signal[:, :, x, y]
        # signal = torch.gather(signal, 2, torch.tensor(x))
        # signal = torch.gather(signal, 3, torch.tensor(y))
        # sample = signal[:, :, x, y]

        return sample

    def sample_bilinear(self, signal, rx, ry, rb, rc):
        signal_dim_x = signal.shape[2]
        signal_dim_y = signal.shape[3]


        # obtain four sample coordinates
        ix0 = rx
        iy0 = ry
        ix1 = ix0 + 1
        iy1 = iy0 + 1

        bounds = (0, signal_dim_x, 0, signal_dim_y)

        # sample signal at each four positions
        signal_00 = self.sample_within_bounds(signal, ix0, iy0, bounds, rb, rc)
        signal_10 = self.sample_within_bounds(signal, ix1, iy0, bounds, rb, rc)
        signal_01 = self.sample_within_bounds(signal, ix0, iy1, bounds, rb, rc)
        signal_11 = self.sample_within_bounds(signal, ix1, iy1, bounds, rb, rc)

        # linear interpolation in x-direction
        fx1 = (ix1 - rx) * signal_00 + (rx - ix0) * signal_10
        fx2 = (ix1 - rx) * signal_01 + (rx - ix0) * signal_11

        # linear interpolation in y-direction
        f = (iy1 - ry) * fx1 + (ry - iy0) * fx2
        return f

    def inv_polar(self, xy, ctr_x, ctr_y, input_size_w, input_size_h, output_size_w, output_size_h):
        y, x = xy[:, 0], xy[:, 1]
        res_y = output_size_h * (1 - torch.sqrt(torch.square(2 * (y - ctr_x[0][0][0][0]) / input_size_w) + torch.square(2 * (x - ctr_y[0][0][0][0]) / input_size_h)))
        fz, fm = y - ctr_x[0][0][0][0], x - ctr_y[0][0][0][0]
        at = torch.arctan(- fz / (fm + 1e-10) * input_size_h / input_size_w)
        mask1 = fz > 0
        mask2 = fm > 0

        at[mask1 & mask2] += 2 * np.pi
        at[mask1 & ~mask2] += np.pi
        at[~ mask1 & mask2] += 0
        at[~ mask1 & ~mask2] += np.pi
        #
        # if fz < 0 and fm > 0:
        #     at = at
        # elif fz > 0 and fm > 0:
        #     at = 2 * np.pi + at
        # else:
        #     at = np.pi + at
        res_x = output_size_w * at / (2 * np.pi)

        ret = torch.stack([res_x, res_y])
        ret = ret.transpose(1, 0)
        return ret

    def forward(self, input, ctr, det_ctrs):
        ctr_x, ctr_y = ctr[:, 0].view(-1, 1, 1, 1), ctr[:, 1].view(-1, 1, 1, 1)
        input_size_w, input_size_h = input.shape[2], input.shape[3]
        output_size_w, output_size_h = input.shape[2] * 4, input.shape[3]
        i = torch.arange(0, output_size_h)
        j = torch.arange(0, output_size_w)
        k = torch.arange(0, ctr.shape[0])
        c = torch.arange(0, 1)
        kk, cc, ii, jj = torch.meshgrid(k, c, i, j)

        y = ctr_x - input_size_w / 2. / output_size_h * (output_size_h - 1 - ii) * torch.sin(2 * np.pi * jj / output_size_w)
        x = ctr_y + input_size_h / 2. / output_size_h * (output_size_h - 1 - ii) * torch.cos(2 * np.pi * jj / output_size_w)


        # bs = torch.LongTensor(kk)
        # c = torch.LongTensor(cc)
            # for ctr in new_ctrs:
            #     for i in range(x.shape[2]):
            #         for j in range(x.shape[3]):
            #             if torch.round(ctr[0]) == x[0][0][i][j] and torch.round(ctr[1]) == y[0][0][i][j]:
            #                 a = 1
            # # TODO
            # x = torch.as_tensor(x, dtype=torch.int64).cuda()
            # y = torch.as_tensor(y, dtype=torch.int64).cuda()
            # image = self.sample_bilinear(input, x, y, kk, cc)
            # return image, new_ctrs


            # cv2.imwrite(output_dir + img.replace('.jpg', '.png'), image)
        x = torch.as_tensor(x, dtype=torch.int64).cuda()
        y = torch.as_tensor(y, dtype=torch.int64).cuda()
        # if det_ctrs is not None:
        #     for ctr in det_ctrs:
        #         xx, yy = int(ctr[0]),int(ctr[1])
        #         if not (xx >= input_size_w and yy >= input_size_h):
        #             input[:, :, xx, yy] = -1
        image = self.sample_bilinear(input, x, y, kk, cc)
        if det_ctrs is not None:
            new_ctrs = self.inv_polar(det_ctrs, ctr_x, ctr_y, input_size_w, input_size_h, output_size_w, output_size_h)
            return image, new_ctrs
        return image

if __name__ == '__main__':
    import cv2
    img = cv2.imread('/home/ganyiyang/document/dmha/v0/output/rgb.png')
    img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    ctr = torch.tensor([[81, 114]])
    input = torch.tensor(img).unsqueeze(0).unsqueeze(0)
    input = torch.as_tensor(input, dtype=torch.float).cuda()
    func = PolarTransform()
    output = func(input, ctr, None)
    cv2.imwrite('/home/ganyiyang/document/dmha/v0/output/test_out.png',
                output[0].permute(1, 2, 0).detach().cpu().numpy())
    pass
    # img = cv2.resize(img, (128, 128))
    # cv2.imwrite('/home/ganyiyang/document/dmha/v2/CenterNet-master/src/test.png', img)
