from torch.utils.data import Dataset
import cv2


class SimpleLoader(Dataset):
    def __init__(self):
        self.top_img = cv2.imread('/home/realgump/documents/deepmha/v2/test_img/0001.jpg', cv2.IMREAD_GRAYSCALE)
        self.hor_img = cv2.imread('/home/realgump/documents/deepmha/v2/test_img/0002.jpg', cv2.IMREAD_GRAYSCALE)
        self.top_img_ls = [self.top_img]
        self.hor_img_ls = [self.hor_img]
        self.center_ls = [[791, 585]]
        self.angle_ls = [90]
        self.label_ls = [1]

    def __len__(self):
        return 1

    def __getitem__(self, item):
        return self.top_img_ls[item], self.hor_img_ls[item], self.center_ls[item], self.angle_ls[item], self.label_ls[item]

if __name__ == '__main__':
    a = SimpleLoader()
    pass
