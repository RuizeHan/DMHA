from torch.serialization import save
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

import json
import os
import torch
import numpy as np
from tqdm import tqdm

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import sys

CENTERNET_PATH = '../../'
sys.path.insert(0, CENTERNET_PATH)
import torch.utils.data as data
from evaluate import evaluate_one


def saveDict(src: dict, save_path: str):
    # Notice that, here the dict is not OrderDict
    with open(save_path, 'w') as f:
        json.dump(src, f)


def iou(box1, box2):
    '''
    box1:[x1, y1, x2,y2]
    box2:[x1, y1, w,h]
    '''
    box2[2] = box2[0] + box2[2]
    box2[3] = box2[1] + box2[3]
    in_h = min(box1[3], box2[3]) - max(box1[1], box2[1])
    in_w = min(box1[2], box2[2]) - max(box1[0], box2[0])
    inner = 0 if in_h < 0 or in_w < 0 else in_h * in_w
    union = (box1[2] - box1[0]) * (box1[3] - box1[1]) + \
            (box2[2] - box2[0]) * (box2[3] - box2[1]) - inner
    iou = inner / union
    return iou


class DHNDataset(data.Dataset):
    def __init__(self, opt, split):
        super(DHNDataset, self).__init__()
        self.opt = opt
        task = 'dhn'
        if split == 'train':
            # self.numpy_file = '/home/ganyiyang/res.npy'
            self.numpy_file = '/HDDs/hdd1/gyy/dmha/dicts/train_wloc_woinv.npy'
        else:
            # self.numpy_file = '/home/ganyiyang/res.npy'
            self.numpy_file = '/HDDs/hdd1/gyy/dmha/dicts/test_wloc_woinv.npy'
        # self.root_dir = '/HDDs/hdd1/gyy/dmha/virtual_data/Data/'
        # self.dateset_dir_top = os.path.join(self.root_dir, 'top_video')
        # self.dataset_dir_hor = os.path.join(self.root_dir, 'hor1_video')

        self.batch_data = np.load(self.numpy_file, allow_pickle=True).item()  # A dict, contain dicts of many frames.
        # Each dict of one frame contains many keys: 'dets_top', 'hm_top', 'angle_top', 'dets_hor', 'hm_hor', 'annos_box_top', 'annos_id_top', 'annos_box_hor', 'annos_id_hor'
        self.fids = list(self.batch_data.keys())

    def __len__(self):
        return len(self.fids)

    def _to_float(self, x):
        return float("{:.2f}".format(x))

    def convert_eval_format(self, all_bboxes):
        # import pdb; pdb.set_trace()
        detections = []
        for image_id in all_bboxes:
            for cls_ind in all_bboxes[image_id]:
                category_id = self._valid_ids[cls_ind - 1]
                for bbox in all_bboxes[image_id][cls_ind]:
                    bbox[2] -= bbox[0]
                    bbox[3] -= bbox[1]
                    score = bbox[4]
                    bbox_out = list(map(self._to_float, bbox[0:4]))

                    detection = {
                        "image_id": int(image_id),
                        "category_id": int(category_id),
                        "bbox": bbox_out,
                        "score": float("{:.2f}".format(score))
                    }
                    if len(bbox) > 5:
                        extreme_points = list(map(self._to_float, bbox[5:13]))
                        detection["extreme_points"] = extreme_points
                    detections.append(detection)
        return detections

    def save_results(self, results, save_dir):
        json.dump(self.convert_eval_format(results),
                  open('{}/results.json'.format(save_dir), 'w'))

    def run_eval(self, results, save_dir):
        report_a = {}
        report_x = {}
        report_y = {}
        report_a['MHIA'] = []
        report_a['f1'] = []
        report_a['prec'] = []
        report_a['recall'] = []
        report_x['MHIA'] = []
        report_x['f1'] = []
        report_x['prec'] = []
        report_x['recall'] = []
        report_y['MHIA'] = []
        report_y['f1'] = []
        report_y['prec'] = []
        report_y['recall'] = []
        for one in results:
            for key in one.keys():
                one[key] = one[key].squeeze(0)
            one_report_a = evaluate_one(one['top'], one['hor'], one['top_gt'], one['hor_gt'],
                                        (one['res_matrix_x'] + one['res_matrix_y']) / 2, one['gt_matrix'])
            one_report_x = evaluate_one(one['top'], one['hor'], one['top_gt'], one['hor_gt'], one['res_matrix_x'],
                                        one['gt_matrix'])
            one_report_y = evaluate_one(one['top'], one['hor'], one['top_gt'], one['hor_gt'], one['res_matrix_y'],
                                        one['gt_matrix'])
            if (one_report_a == False or one_report_x == False or one_report_y == False):
                continue
            report_a['MHIA'].append(one_report_a['MHIA'])
            report_a['f1'].append(one_report_a['f1'])
            report_a['prec'].append(one_report_a['prec'])
            report_a['recall'].append(one_report_a['recall'])
            report_x['MHIA'].append(one_report_x['MHIA'])
            report_x['f1'].append(one_report_x['f1'])
            report_x['prec'].append(one_report_x['prec'])
            report_x['recall'].append(one_report_x['recall'])
            report_y['MHIA'].append(one_report_y['MHIA'])
            report_y['f1'].append(one_report_y['f1'])
            report_y['prec'].append(one_report_y['prec'])
            report_y['recall'].append(one_report_y['recall'])
        saveDict(report_a, os.path.join(save_dir, 'a.json'))
        saveDict(report_x, os.path.join(save_dir, 'x.json'))
        saveDict(report_y, os.path.join(save_dir, 'y.json'))
        s = lambda x: sum(x) / len(x)
        stat_a = {'MHIA': s(report_a['MHIA']), 'f1': s(report_a['f1']), 'prec': s(report_a['prec']),
                  'recall': s(report_a['recall'])}
        stat_x = {'MHIA': s(report_x['MHIA']), 'f1': s(report_x['f1']), 'prec': s(report_x['prec']),
                  'recall': s(report_x['recall'])}
        stat_y = {'MHIA': s(report_y['MHIA']), 'f1': s(report_y['f1']), 'prec': s(report_y['prec']),
                  'recall': s(report_y['recall'])}
        saveDict(stat_a, os.path.join(save_dir, 'sa.json'))
        saveDict(stat_x, os.path.join(save_dir, 'sx.json'))
        saveDict(stat_y, os.path.join(save_dir, 'sy.json'))
        print(report_a)
        print(report_x)
        print(report_y)


class DHNSampler(data.Dataset):
    def __getitem__(self, item):
        ret_dict = self.batch_data[self.fids[item]]
        for key in ret_dict.keys():
            if type(ret_dict[key]) == np.ndarray:
                ret_dict[key] = torch.from_numpy(ret_dict[key])
            elif type(ret_dict[key]) == list:
                ret_dict[key] = torch.Tensor(ret_dict[key])
        return ret_dict


import math


def divide_virtual_train_test(npy_path):
    ori_data = np.load(npy_path, allow_pickle=True).item()
    num = len(ori_data.keys())
    available_fids = []
    # print('original keys:')
    # print(ori_data.keys())
    # Filter useless
    print('--------All num: %d-------' % num)
    print('----------- Filtering useless-----------')
    for i in range(num):
        index_gt = ori_data[i]['id_top_gt'].index(ori_data[i]['location_gt'])
        bbox_pred = ori_data[i]['dets_top_ori'][ori_data[i]['location_pred']]
        bbox_gt = ori_data[i]['dets_top_gt'][index_gt]
        IOU = iou(bbox_pred, bbox_gt)
        obs_correct = IOU > 0.5
        angle_correct = min(ori_data[i]['angle_pred'] + 360 - ori_data[i]['angle_gt'],
                            ori_data[i]['angle_gt'] + 360 - ori_data[i]['angle_pred'],
                            abs(ori_data[i]['angle_gt'] - ori_data[i]['angle_pred'])) < 20
        if obs_correct & angle_correct & (len(ori_data[i]['id_hor_gt']) != 0) & (len(ori_data[i]['id_top_gt']) != 0):
            available_fids.append(i)
        # if not obs_correct:
        # print(IOU)
    ava_num = len(available_fids)
    print('----------Over, available frame num: %d--------' % ava_num)
    # Divide into train set and test set
    train_num = ava_num // 2
    test_num = ava_num - ava_num // 2
    train_dict = {}
    test_dict = {}
    choice = np.random.choice(ava_num, ava_num, replace=False)
    for i in range(train_num):
        train_dict[i] = ori_data[available_fids[choice[i]]]
    for i in range(train_num, train_num + test_num):
        test_dict[i] = ori_data[available_fids[choice[i]]]
    # Save to disk
    with open('/HDDs/hdd1/gyy/dmha/dicts/train.npy', 'wb') as f:
        np.save(f, train_dict)
    with open('/HDDs/hdd1/gyy/dmha/dicts/test.npy', 'wb') as f:
        np.save(f, test_dict)


def select_ava(npy_path, name):
    ori_data = np.load(npy_path, allow_pickle=True).item()
    num = len(ori_data.keys())
    available_fids = []
    # print('original keys:')
    # print(ori_data.keys())
    # Filter useless
    print('--------All num: %d-------' % num)
    print('----------- Filtering useless-----------')
    for i in range(num):
        if ori_data[i]['frame'] == '41_1':
            print('debug')
        index_gt = ori_data[i]['id_top_gt'].index(ori_data[i]['location_gt'])
        bbox_pred = ori_data[i]['dets_top_ori'][ori_data[i]['location_pred']]
        bbox_gt = ori_data[i]['dets_top_gt'][index_gt]
        IOU = iou(bbox_pred, bbox_gt)
        obs_correct = IOU > 0.5
        angle_correct = min(ori_data[i]['angle_pred'] + 360 - ori_data[i]['angle_gt'],
                            ori_data[i]['angle_gt'] + 360 - ori_data[i]['angle_pred'],
                            abs(ori_data[i]['angle_gt'] - ori_data[i]['angle_pred'])) < 20

        # Filtering bad boxes
        ava_bbox_list = []
        det_top_ori = []
        f = lambda x: (~np.isnan(x)) & (x >= 0) & (x <= 128)
        for ni in range(ori_data[i]['dets_top_pred'].shape[0]):
            if ori_data[i]['frame'] == '41_1':
                print('debug')
            box = ori_data[i]['dets_top_pred'][ni]
            if f(box[0]) & f(box[1]):
                ava_bbox_list.append(box)
                det_top_ori.append(ori_data[i]['dets_top_ori'][ni])
        if len(ava_bbox_list) == 0:
            noBox = True
        else:
            noBox = False
            ori_data[i]['dets_top_pred'] = np.stack(ava_bbox_list, axis=0)
            ori_data[i]['dets_top_ori'] = np.stack(det_top_ori, axis=0)

        if (not noBox) & obs_correct & angle_correct & (len(ori_data[i]['id_hor_gt']) != 0) & (
                len(ori_data[i]['id_top_gt']) != 0):
            available_fids.append(i)
        else:
            # print(noBox,obs_correct,angle_correct,(len(ori_data[i]['id_hor_gt'])!=0),(len(ori_data[i]['id_top_gt'])!=0))
            if noBox:
                print('no box', ori_data[i]['frame'])
            if (len(ori_data[i]['id_hor_gt']) == 0) or (len(ori_data[i]['id_top_gt']) == 0):
                print('gt no box', ori_data[i]['frame'])
        # if not obs_correct:
        # print(IOU)
    ava_num = len(available_fids)
    print('----------Over, available frame num: %d--------' % ava_num)
    # Divide into train set and test set
    train_num = ava_num // 2
    test_num = ava_num - ava_num // 2
    train_dict = {}
    test_dict = {}
    choice = np.random.choice(ava_num, ava_num, replace=False)
    for i in range(ava_num):
        train_dict[i] = ori_data[available_fids[choice[i]]]
    # for i in range(train_num,train_num+test_num):
    #   test_dict[i]=ori_data[available_fids[choice[i]]]
    # Save to disk
    with open(name, 'wb') as f:
        np.save(f, train_dict)


if __name__ == '__main__':
    # loader = DHNDataset()
    save_path = '/HDDs/hdd1/gyy/dmha/dicts'
    save_path = os.path.join(save_path, 'res.npy')
    # divide_virtual_train_test(save_path)
    select_ava('/HDDs/hdd1/gyy/dmha/dicts/train_wloc_woinv.npy', '/HDDs/hdd1/gyy/dmha/dicts/train.npy')
    select_ava('/HDDs/hdd1/gyy/dmha/dicts/test_wloc_woinv.npy', '/HDDs/hdd1/gyy/dmha/dicts/test.npy')
    # res = {}
    # for i, data in tqdm(enumerate(loader), total=len(loader)):
    #     res[i] = data

    # np.save(save_path, res)