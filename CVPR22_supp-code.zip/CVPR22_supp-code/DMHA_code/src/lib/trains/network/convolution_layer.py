import torch.nn as nn
import torch
# import config
import torch.nn.functional as F

def draw_curves(a, b):
    import cv2
    import matplotlib.pyplot as plt
    import numpy as np
    plt.close('all')
    curve1 = a[0].detach().cpu().numpy()
    curve2 = b[0].detach().cpu().numpy()
    zero1 = np.zeros((512-128))
    curve2 = np.concatenate([curve2, zero1])
    x1 = np.arange(0, curve1.shape[-1])
    x2 = np.arange(0, curve2.shape[-1])
    y1 = curve1
    y2 = curve2
    plt.plot(x1, y1)
    plt.savefig('/home/ganyiyang/document/dmha/v0/output/6.png')
    plt.savefig('/home/ganyiyang/document/dmha/v0/output/6.eps')
    plt.close('all')
    plt.plot(x1, y2)

    plt.savefig('/home/ganyiyang/document/dmha/v0/output/7.png')
    plt.savefig('/home/ganyiyang/document/dmha/v0/output/7.eps')

class ConvLayer(nn.Module):
    def __init__(self, vis=0):
        super(ConvLayer, self).__init__()
        self.vis = vis
        # self.conv = nn.Conv2d()

    def forward(self, img_360, img_hor, dim):
        # img_360 = F.normalize(img_360, p=2)
        # img_hor = F.normalize(img_hor, p=2)
        cropped_top, angle_pred, angle_curve, img_hor_compress = self.corr_crop_distance(img_360, img_hor, dim)
        return cropped_top, angle_pred, angle_curve, img_hor_compress
    # @profile
    def corr_crop_distance(self, img_360, img_hor, dim):
        corr_out, corr_orien, angle_curve, img_hor_compress, img_360_compress = self.corr(img_360, img_hor)
        if dim == '2d':
            cropped_top = self.crop_sat(img_360, corr_orien, img_hor.shape[2])
        elif dim == '1d':
            cropped_top = self.crop_sat(img_360_compress, corr_orien, img_hor.shape[2])
        # return cropped_top, corr_orien / img_hor.shape[2] / 4  * 360
        return cropped_top, corr_orien / img_hor.shape[2] / 4  * 360, angle_curve, img_hor_compress
    # @profile
    def crop_sat(self, img_360, corr_orien, w):
        crop_img = torch.cat((img_360, img_360[:,:,:,:w]), dim=-1)
        ret = torch.stack([crop_img[i, :, :, corr_orien[i]:corr_orien[i] + w] for i in range(corr_orien.shape[0])])
        # TODO
        return ret
    # @profile
    def corr(self, img_360, img_hor):
        w = img_hor.shape[2]
        # img_360 = torch.cat([img_360, img_360[:, :, :, :w]], dim=-1)
        img_360[:, :, 100:, :] = 0
        # img_360_trans = img_360.permute(1, 0, 2, 3)
        # for i in range(img_360.shape[0]):
        # img_360 = img_360 - torch.mean(img_360, dim=-1).unsqueeze(-1)
        # img_hor = img_hor - torch.mean(img_hor, dim=-1).unsqueeze(-1)
        img_360 = F.relu(img_360 - 0.2)
        img_hor = F.relu(img_hor - 0.2)
        # img_360 = img_360 * img_ = 0
        # img_hor = img_hor * img_hor < 0.4 = 0

        img_360_compress = torch.sum(img_360, dim=2, keepdim=True)
        img_hor_compress = torch.sum(img_hor, dim=2, keepdim=True)

        # img_360_compress = torch.max(img_360, dim=2, keepdim=True).values
        # img_hor_compress = torch.max(img_hor, dim=2, keepdim=True).values


        img_360_compress = torch.cat(
            [F.conv2d(img_360_compress[i:i + 1, :, :, :], torch.ones([1, 1, 1, 3]).cuda(), padding=(0, 1)) for i in
             range(img_360.shape[0])], dim=0)
        img_hor_compress = torch.cat(
            [F.conv2d(img_hor_compress[i:i + 1, :, :, :], torch.ones([1, 1, 1, 3]).cuda(), padding=(0, 1)) for i in
             range(img_360.shape[0])], dim=0)

        # img_360_compress = F.normalize(img_360_compress, dim=-1)
        # img_hor_compress = F.normalize(img_hor_compress, dim=-1)
        img_360_compress = img_360_compress / (torch.max(img_360_compress, dim=-1, keepdim=True).values + 1e-8)
        img_hor_compress = img_hor_compress / (torch.max(img_hor_compress, dim=-1, keepdim=True).values + 1e-8)

        # transx = lambda x: 1 / (1 + torch.exp(-20 * 0.9 * x + 10))
        # img_360_compress = transx(img_360_compress)
        # img_hor_compress = transx(img_hor_compress)

        img_360_compress_ = torch.cat([img_360_compress, img_360_compress[:, :, :, :w]], dim=-1)
        if self.vis:
            draw_curves(img_360_compress[0][0], img_hor_compress[0][0])
        # img_360_compress = F.conv2d(img_360_compress, img_hor_compress, stride=1)
        out = torch.cat(
            [F.conv2d(img_360_compress_[i:i + 1, :, :, :], img_hor_compress[i:i + 1, :, :, :], stride=1) for i in
             range(img_360.shape[0])], dim=0)

        # out_ori = torch.cat([F.conv2d(img_360[i:i + 1, :, :, :], img_hor[i:i + 1, :, :, :], stride=1) for i in range(img_360.shape[0])], dim=0)
        # out = torch.cat([F.conv1d(img_360_compress[i:i+1, :, :, :], img_hor_compress[i:i+1, :, :, :], stride=1) for i in range(img_360.shape[0])], dim=0)
        out_curve = torch.reshape(out,(img_360.shape[0], -1))
        # out = F.conv2d(img_360, img_hor, stride=[1, 1, 1, 1], padding='VALID')
        orien = torch.argmax(out_curve, dim=1)
        return out, orien, out_curve, img_hor_compress, img_360_compress


