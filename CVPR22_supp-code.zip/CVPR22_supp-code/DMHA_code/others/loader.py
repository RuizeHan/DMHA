from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import os
import xml.etree.ElementTree as ET
import numpy as np
import cv2
import copy
import torch


class Loader(Dataset):
    def __init__(self):
        self.root_dir = '/dataset/MMM/dataset_interaction/'
        self.view_src_ls = ['GoPro1']
        self.view_tgt_ls = ['U']
        self.scene_list = ['exchange']

        self.data_dir_src_ls = [os.path.join(self.root_dir, 'frame_sel', i, j) for i in self.view_src_ls for j in
                                self.scene_list]
        self.data_dir_tgt_ls = [os.path.join(self.root_dir, 'frame_sel', i, j) for i in self.view_tgt_ls for j in
                                self.scene_list]
        self.anno_dir_src_ls = [os.path.join(self.root_dir, 'Annotations_2021', i, j) for i in self.view_src_ls for j in
                                self.scene_list]
        self.anno_dir_tgt_ls = [os.path.join(self.root_dir, 'Annotations_2021', i, j) for i in self.view_tgt_ls for j in
                                self.scene_list]

        self.data_path_src_ls = self.sort_dir(self.data_dir_src_ls)
        self.data_path_tgt_ls = self.sort_dir(self.data_dir_tgt_ls)
        self.anno_path_src_ls = self.sort_dir(self.anno_dir_src_ls)
        self.anno_path_tgt_ls = self.sort_dir(self.anno_dir_tgt_ls)

        self.len = len(self.data_path_tgt_ls)

    def sort_dir(self, input):
        output = []
        for dir in input:
            path_ls = os.listdir(dir)
            path_ls.sort(key=lambda x: int(x[:-4]))
            path_ls = [os.path.join(dir, i) for i in path_ls]
            output += (path_ls[:100])
        return output

    def read_anno(self, path):
        xml_tree = ET.parse(path)
        xml_objects = xml_tree.findall('object')
        box_dict = {}
        for object_i in xml_objects:
            person_id = object_i.find('name').text
            bbox = object_i.find('rectangle')
            bbox_xmin = int(float(bbox.find('xmin').text))
            bbox_ymin = int(float(bbox.find('ymin').text))
            bbox_xmax = int(float(bbox.find('xmax').text))
            bbox_ymax = int(float(bbox.find('ymax').text))
            box_dict[person_id] = [bbox_xmin, bbox_ymin, bbox_xmax, bbox_ymax]
        return box_dict

if __name__ == '__main__':
    a = Loader()
    for i in a:
        print(i)