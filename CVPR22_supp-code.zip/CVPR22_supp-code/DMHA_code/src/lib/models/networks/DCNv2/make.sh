#!/usr/bin/env bash
python setup.py build develop
