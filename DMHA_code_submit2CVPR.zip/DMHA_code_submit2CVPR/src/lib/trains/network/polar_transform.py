import torch.nn as nn
import numpy as np
import torch

class PolarTransform(nn.Module):
    def __init__(self):
        super(PolarTransform, self).__init__()
        # self.input_size_w = 14
        # self.input_size_h = 14
        # self.output_size_w = 56
        # self.output_size_h = 14

    def sample_within_bounds(self, signal, x, y, bounds):
        xmin, xmax, ymin, ymax = bounds

        idxs = (xmin <= x) & (x < xmax) & (ymin <= y) & (y < ymax)

        sample = np.zeros((x.shape[0], x.shape[1], signal.shape[-1]))
        sample[idxs, :] = signal[x[idxs], y[idxs], :]

        return sample

    def sample_bilinear(self, signal, rx, ry):
        signal_dim_x = signal.shape[0]
        signal_dim_y = signal.shape[1]

        # obtain four sample coordinates
        ix0 = rx.astype(int)
        iy0 = ry.astype(int)
        ix1 = ix0 + 1
        iy1 = iy0 + 1

        bounds = (0, signal_dim_x, 0, signal_dim_y)

        # sample signal at each four positions
        signal_00 = self.sample_within_bounds(signal, ix0, iy0, bounds)
        signal_10 = self.sample_within_bounds(signal, ix1, iy0, bounds)
        signal_01 = self.sample_within_bounds(signal, ix0, iy1, bounds)
        signal_11 = self.sample_within_bounds(signal, ix1, iy1, bounds)

        na = np.newaxis
        # linear interpolation in x-direction
        fx1 = (ix1 - rx)[..., na] * signal_00 + (rx - ix0)[..., na] * signal_10
        fx2 = (ix1 - rx)[..., na] * signal_01 + (rx - ix0)[..., na] * signal_11

        # linear interpolation in y-direction
        return (iy1 - ry)[..., na] * fx1 + (ry - iy0)[..., na] * fx2

    def gen_grid(self, ctr):
        i = np.arange(0, self.output_size_h)
        j = np.arange(0, self.output_size_w)
        jj, ii = np.meshgrid(j, i)

        ctr_x, ctr_y = ctr
        y = ctr_x - self.input_size_w / 2. / self.output_size_h * (self.output_size_h - 1 - ii) * np.sin(2 * np.pi * jj / self.output_size_w)
        x = ctr_y + self.input_size_h / 2. / self.output_size_h * (self.output_size_h - 1 - ii) * np.cos(2 * np.pi * jj / self.output_size_w)
        return x, y

    def forward(self, input, ctr):
        input_size_w, input_size_h = input.shape[2], input.shape[3]
        output_size_w, output_size_h = input_size_w * 4, input_size_h
        batch_size = input.shape[0]

        output = torch.zeros(batch_size, 1, output_size_h, output_size_w).cuda()
        for i in range(output_size_h):
            for j in range(output_size_w):
                for k in range(batch_size):
                    ctr_x, ctr_y = ctr[k][0], ctr[k][1]
                    idx = ctr_x - input_size_w / 2. / output_size_h * (output_size_h - 1 - i) * np.sin(
                        2 * np.pi * j / output_size_w)
                    idy = ctr_y + input_size_h / 2. / output_size_h * (output_size_h - 1 - i) * np.cos(
                        2 * np.pi * j / output_size_w)
                    idx = int(idx)
                    idy = int(idy)
                    if (0 <= idx) & (idx < input_size_w) & (0 <= idy) & (idy < input_size_h):
                        output[k, :, i, j] = input[k, :, idx, idy]
        return output

if __name__ == '__main__':
    import cv2
    model = PolarTransform()
    img = cv2.imread('../test_img/0001.jpg')
    x = model(img, (791, 585))
    pass