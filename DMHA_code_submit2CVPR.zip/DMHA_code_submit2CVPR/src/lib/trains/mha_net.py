import torch.nn as nn
import torch
import torch.nn.functional as F
# import config
from .network.polar_transform_1 import PolarTransform
from .network.convolution_layer import ConvLayer

# architecture
# 1 toheatmap
# from network.polar_transform import PolarTransform

class MHANet(nn.Module):
    def __init__(self):
        super(MHANet, self).__init__()
        self.polar_layer = PolarTransform()
        self.Conv = ConvLayer()
        self.mse = nn.MSELoss()

    def l2_loss(self, pred, gt):
        # sigma = 1
        pred = F.normalize(pred, dim=1)
        gt = F.normalize(gt, dim=1)
        return self.mse(pred, gt)

    def triplet_loss(self, pred_pos, pred_neg, pred_hor):
        # pred_pos = F.normalize(pred_pos, dim=-1)
        # pred_neg = F.normalize(pred_neg, dim=-1)

        alpha = 100
        mse = self.mse
        loss = torch.log(1 + torch.exp(alpha * (mse(pred_pos, pred_hor) - mse(pred_neg, pred_hor))))
        return loss

    def forward(self, hm_top, hm_hor, ctr_pos, ctr_neg, angle_gt):
        top_360_pos = self.polar_layer(hm_top, ctr_pos, None)
        top_360_neg = self.polar_layer(hm_top, ctr_neg, None)

        cropped_top_pos, angle_pred_pos, angle_curve_pos, hor_compress = self.Conv(top_360_pos,hm_hor, '2d')
        cropped_top_neg, _, _, _ = self.Conv(top_360_neg, hm_hor, '2d')

        triplet_loss = self.triplet_loss(cropped_top_pos, cropped_top_neg, hor_compress) * 1e0
        # triplet_loss = self.triplet_loss(cropped_top_pos, cropped_top_neg)
        l2_loss = self.l2_loss(angle_curve_pos, angle_gt) * 1e2

        ret = {'360': top_360_pos, 'cropped_top_hm': cropped_top_pos, 'top_hm': hm_top, 'hor_hm': hm_hor, 'angle_pred_pos': angle_pred_pos}
        # loss = {'loss': triplet_loss + l2_loss, 'l2_loss': l2_loss, 'triplet_loss': triplet_loss}
        # loss = {'loss': 0, 'l2_loss': l2_loss, 'triplet_loss': triplet_loss}
        loss = {'loss': triplet_loss, 'l2_loss': l2_loss, 'triplet_loss': triplet_loss}
        # loss = {'loss': l2_loss, 'l2_loss': l2_loss, 'triplet_loss': triplet_loss}

        return ret, loss
