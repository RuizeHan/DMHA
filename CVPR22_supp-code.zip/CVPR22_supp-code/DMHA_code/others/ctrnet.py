import sys
CENTERNET_PATH = '/home/ganyiyang/document/dmha/v2/CenterNet-master/src/lib'
sys.path.insert(0, CENTERNET_PATH)

from detectors.detector_factory import detector_factory
from opts import opts

MODEL_PATH = '/home/ganyiyang/document/dmha/v2/CenterNet-master/models/ctdet_coco_dla_2x.pth'
TASK = 'ctdet' # or 'multi_pose' for human pose estimation
opt = opts().init('{} --load_model {} --debug {}'.format(TASK, MODEL_PATH, 2).split(' '))
detector = detector_factory[opt.task](opt)

img = '/home/ganyiyang/document/dmha/v2/CenterNet-master/images/0001.jpg'
ret = detector.run(img)['results']
pass

