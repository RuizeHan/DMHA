import torch.nn as nn
import numpy as np
import torch

class PolarTransform(nn.Module):
    def __init__(self):
        super(PolarTransform, self).__init__()
        self.input_size_w = 14
        self.input_size_h = 14
        self.output_size_w = 56
        self.output_size_h = 14

    def sample_within_bounds(self, signal, x, y, bounds):
        xmin, xmax, ymin, ymax = bounds

        idxs = (xmin <= x) & (x < xmax) & (ymin <= y) & (y < ymax)

        sample = np.zeros((x.shape[0], x.shape[1], signal.shape[-1]))
        sample[idxs, :] = signal[x[idxs], y[idxs], :]

        return sample

    def sample_bilinear(self, signal, rx, ry):
        signal_dim_x = signal.shape[0]
        signal_dim_y = signal.shape[1]

        # obtain four sample coordinates
        ix0 = rx.astype(int)
        iy0 = ry.astype(int)
        ix1 = ix0 + 1
        iy1 = iy0 + 1

        bounds = (0, signal_dim_x, 0, signal_dim_y)

        # sample signal at each four positions
        signal_00 = self.sample_within_bounds(signal, ix0, iy0, bounds)
        signal_10 = self.sample_within_bounds(signal, ix1, iy0, bounds)
        signal_01 = self.sample_within_bounds(signal, ix0, iy1, bounds)
        signal_11 = self.sample_within_bounds(signal, ix1, iy1, bounds)

        na = np.newaxis
        # linear interpolation in x-direction
        fx1 = (ix1 - rx)[..., na] * signal_00 + (rx - ix0)[..., na] * signal_10
        fx2 = (ix1 - rx)[..., na] * signal_01 + (rx - ix0)[..., na] * signal_11

        # linear interpolation in y-direction
        return (iy1 - ry)[..., na] * fx1 + (ry - iy0)[..., na] * fx2

    def gen_grid(self, ctr):
        i = np.arange(0, self.output_size_h)
        j = np.arange(0, self.output_size_w)
        jj, ii = np.meshgrid(j, i)

        ctr_x, ctr_y = ctr
        y = ctr_x - self.input_size_w / 2. / self.output_size_h * (self.output_size_h - 1 - ii) * np.sin(2 * np.pi * jj / self.output_size_w)
        x = ctr_y + self.input_size_h / 2. / self.output_size_h * (self.output_size_h - 1 - ii) * np.cos(2 * np.pi * jj / self.output_size_w)
        return x, y

    def forward(self, input, ctr):
        ctr_x, ctr_y = int(ctr[0]), int(ctr[1])
        output = torch.zeros(1, self.output_size_h, self.output_size_w)
        for i in range(self.output_size_h):
            for j in range(self.output_size_w):
                idx = ctr_x - self.input_size_w / 2. / self.output_size_h * (self.output_size_h - 1 - i) * np.sin(
                    2 * np.pi * j / self.output_size_w)
                idy = ctr_y + self.input_size_h / 2. / self.output_size_h * (self.output_size_h - 1 - i) * np.cos(
                    2 * np.pi * j / self.output_size_w)
                idx = int(idx)
                idy = int(idy)
                output[:, i, j] = input[:, idx, idy]
        return output


if __name__ == '__main__':
    import cv2
    model = PolarTransform()
    img = cv2.imread('../test_img/0001.jpg')
    x = model(img, (791, 585))
    pass