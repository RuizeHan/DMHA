'''
Result form:
1. {seq_name: action}
2. {seq_name: this action: who are interacting with each other.} {seq_name: for the given bounding boxes give their
probability of being interactors. Top-2 accuracy.}

seq-action-acc: /frac{num_correct_seq_pred}{num_seq}
seq_actors-acc-top2: /frac{num_top2actors_matched}{num_seq}

file form:
dict{'seq_name': dict{'action':int, 'actors': char(Follow the given bounding boxes order)}}
For the predicted action, choose the two pid that have highest probability of doing this action.
use json file.
'''

import os
from os.path import join
from os import mkdir, listdir

from collections import OrderedDict

import cv2
import PIL
import numpy as np
import torch

import xml.etree.ElementTree as ET

import random
from PIL import Image

import numpy as np

from collections import Counter
import os

from pathlib import Path

from os.path import exists

from copy import deepcopy
import json
import shutil

import tqdm


import torch

def intersect(box_a, box_b):
    """ We resize both tensors to [A,B,2] without new malloc:
    [A,2] -> [A,1,2] -> [A,B,2]
    [B,2] -> [1,B,2] -> [A,B,2]
    Then we compute the area of intersect between box_a and box_b.
    Args:
      box_a: (tensor) bounding boxes, Shape: [A,4].
      box_b: (tensor) bounding boxes, Shape: [B,4].
    Return:
      (tensor) intersection area, Shape: [A,B].
    """
    A = box_a.size(0)
    B = box_b.size(0)
    max_xy = torch.min(box_a[:, 2:].unsqueeze(1).expand(A, B, 2),
                       box_b[:, 2:].unsqueeze(0).expand(A, B, 2))
    min_xy = torch.max(box_a[:, :2].unsqueeze(1).expand(A, B, 2),
                       box_b[:, :2].unsqueeze(0).expand(A, B, 2))
    inter = torch.clamp((max_xy - min_xy), min=0)
    return inter[:, :, 0] * inter[:, :, 1]
    # inter[:, :, 0] is the width of intersection and inter[:, :, 1] is height


def get_IOU(box_a, box_b_):
    # WARNING! There is a shit in the above code. box_a: x1y1x2y2, BUT!
    # box_b_: x1y1wh. I don't know why they keep this stupid setting.
    """Compute the jaccard overlap of two sets of boxes.  The jaccard overlap
    is simply the intersection over union of two boxes.  Here we operate on
    ground truth boxes and default boxes.
    E.g.:
        A ∩ B / A ∪ B = A ∩ B / (area(A) + area(B) - A ∩ B)
    Args:
        box_a: (tensor) Ground truth bounding boxes, Shape: [A,4]
        box_b: (tensor) Prior boxes from priorbox layers, Shape: [B,4]
    Return:
        jaccard overlap: (tensor) Shape: [A, B]
    """
    box_b=box_b_.clone()
    box_b[:,2]=box_b_[:,2]+box_b_[:,0]
    box_b[:,3]=box_b_[:,3]+box_b_[:,1]
    
    inter = intersect(box_a, box_b)
    area_a = ((box_a[:, 2]-box_a[:, 0]) *
              (box_a[:, 3]-box_a[:, 1])).unsqueeze(1).expand_as(inter)  # [A,B]
    area_b = ((box_b[:, 2]-box_b[:, 0]) *
              (box_b[:, 3]-box_b[:, 1])).unsqueeze(0).expand_as(inter)  # [A,B]
    union = area_a + area_b - inter
    return inter / union  # [A,B]

def print_log(file_path,*args):
    print(*args)
    if file_path is not None:
        with open(file_path, 'a') as f:
            print(*args,file=f)

def saveDict(src: dict, save_path: str):
    # Notice that, here the dict is not OrderDict
    with open(save_path, 'w') as f:
        json.dump(src, f)


def safeMkdir(path: str):
    if exists(path):
        return
    else:
        mkdir(path)


def drawBoundingBox(imgPath: str, bboxes: dict, savePath: str):
    img = cv2.imread(imgPath)
    img = cv2.UMat(img).get()
    font = cv2.FONT_HERSHEY_SIMPLEX
    for key in bboxes.keys():
        bbox = bboxes[key]
        bbox = [int(i) for i in bbox]
        text = str(key)
        f = lambda x: (int(x[0]), int(x[1]))
        cv2.rectangle(img, f(bbox[:2]), f(bbox[2:]), (0, 255, 0), 4)
        cv2.putText(img, text, f(bbox[:2]), font, 2, (0, 0, 255), 1)
    cv2.imwrite(savePath, img)


def plot_confusion_matrix(cm,
                          target_names,
                          save_path='./result.svg',
                          title='Confusion matrix',
                          cmap=None,
                          normalize=True,
                          ):
    """
    given a sklearn confusion matrix (cm), make a nice plot

    Arguments
    ---------
    cm:           confusion matrix from sklearn.metrics.confusion_matrix

    target_names: given classification classes such as [0, 1, 2]
                  the class names, for example: ['high', 'medium', 'low']

    save_path:    path to save image.

    title:        the text to display at the top of the matrix

    cmap:         the gradient of the values displayed from matplotlib.pyplot.cm
                  see http://matplotlib.org/examples/color/colormaps_reference.html
                  plt.get_cmap('jet') or plt.cm.Blues

    normalize:    If False, plot the raw numbers
                  If True, plot the proportions

    Usage
    -----
    plot_confusion_matrix(cm           = cm,                  # confusion matrix created by
                                                              # sklearn.metrics.confusion_matrix
                          normalize    = True,                # show proportions
                          target_names = y_labels_vals,       # list of names of the classes
                          title        = best_estimator_name) # title of graph

    Citiation
    ---------
    http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html

    plot_confusion_matrix(cm           = np.array([[ 1098,  1934,   807],
                                              [  604,  4392,  6233],
                                              [  162,  2362, 31760]]),
                      normalize    = False,
                      target_names = ['high', 'medium', 'low'],
                      title        = "Confusion Matrix")

    """
    import matplotlib
    import matplotlib.pyplot as plt
    import numpy as np
    import itertools
    matplotlib.use('Agg')
    accuracy = np.trace(cm) / float(np.sum(cm))
    misclass = 1 - accuracy

    if cmap is None:
        cmap = plt.get_cmap('Blues')

    plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()

    if target_names is not None:
        tick_marks = np.arange(len(target_names))
        plt.xticks(tick_marks, target_names, rotation=45)
        plt.yticks(tick_marks, target_names)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    thresh = cm.max() / 1.5 if normalize else cm.max() / 2
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(j, i, "{:0.4f}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
        else:
            plt.text(j, i, "{:,}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label\naccuracy={:0.4f}; misclass={:0.4f}'.format(accuracy, misclass))
    plt.savefig(save_path)
    plt.close()


def evaluate_one(top,hor,top_gt,hor_gt,res_matrix,gt_matrix,thr_top=20,thr_hor=0.5):
    getNAN=False
    res_matrix=(res_matrix==res_matrix.max(dim=1)[0][:,None]).int()
    # res_matrix=res_matrix.T
    # res_matrix=(res_matrix==res_matrix.max(dim=0)[0]).int()
    top=torch.cat([(top[:,0,None]+top[:,2,None])/2,(top[:,1,None]+top[:,3,None])/2],dim=-1)
    top_gt=torch.cat([top_gt[:,0,None]+0.5*top_gt[:,2,None],top_gt[:,1,None]+0.5*top_gt[:,3,None]],dim=-1) # N,2
    T_dis=(torch.sqrt((top[:,None,:]-top_gt[None,:,:])**2)).sum(dim=-1) # M,N

    zero = torch.zeros_like(T_dis)
    one = torch.ones_like(T_dis)
    # T = torch.where(T_dis <= thr_top, one, T_dis)
    # T_trans = torch.where(T > thr_top, zero, T)
    T_trans = torch.where(T_dis > thr_top, zero, one)
    
    num_T_more=(T_trans.sum(dim=-1)==0).sum()
    num_T_less=(T_trans.sum(dim=-2)==0).sum()

    # hor view

    # thr_hor = 0.5  # the threshold for top view 
    box_h = hor.reshape(-1,4)
    box_h_gt = hor_gt.reshape(-1,4)

    # H_iou = [get_IOU(box_h[i],box_h_gt[j]) for i in range(len(box_h)) for j in range(len(box_h_gt))]
    H_iou=get_IOU(box_h,box_h_gt)

    zero = torch.zeros_like(H_iou)
    one = torch.ones_like(H_iou)
    # H = torch.where(T_dis >= thr_hor, one, H_iou)
    H_trans = torch.where(H_iou < thr_hor, zero, one)
    num_H_more=(H_trans.sum(dim=-1)==0).sum()
    num_H_less=(H_trans.sum(dim=-2)==0).sum()

    # gt2res = torch.chain_matmul(T_trans , gt_matrix , H_trans.transpose(1,2))
    gt2res=torch.matmul(torch.matmul(T_trans , gt_matrix),H_trans.transpose(0,1))
    gt2res.clamp_max_(1)
    if not(gt2res.max()<=1 and gt2res.min()>=0):
        print(gt2res.max())
        print(gt2res.min())

    tp=((gt2res==res_matrix)&(gt2res==1)).sum()
    # fp=((res_matrix==1)&(gt2res==0)&(gt2res.sum(dim=-2,keepdim=True)!=0)).sum()
    fp=((res_matrix==1)&(gt2res==0)).sum()
    # fn=((res_matrix==0)&(gt2res.sum(dim=-1,keepdim=True)!=0)&(gt2res==1)).sum()
    fn=((res_matrix==0)&(gt2res==1)).sum()


    prec=tp/(tp+fp)
    recall=tp/(tp+fn)
    f1=2*prec*recall/(prec+recall)
    if recall!=recall or prec!=prec or f1!=f1:
        return False

    mst=num_H_less+num_T_less+((res_matrix.sum(dim=-1)==0)&(gt2res.sum(dim=-1)>0)).sum()+((res_matrix.sum(dim=-2)==0)&(gt2res.sum(dim=-2)>0)).sum()
    fpt=((res_matrix.sum(dim=-1)>0)&(gt2res.sum(dim=-1)==0)).sum()+((res_matrix.sum(dim=-2)>0)&(gt2res.sum(dim=-2)==0)).sum()#+num_H_more+num_T_more
    mmet=((res_matrix.sum(dim=-1,keepdim=True)>0)&(gt2res.sum(dim=-1,keepdim=True)>0)&(res_matrix.sum(dim=-2,keepdim=True)>0)&(gt2res.sum(dim=-2,keepdim=True)>0)&(res_matrix!=gt2res)).sum()
    

    MHIA = 1 - (mst + fpt + mmet*2) / (gt_matrix.shape[0]+gt_matrix.shape[1]+num_H_more+num_T_more)

    report = {}
    report['MHIA'] = MHIA.tolist()
    report['f1'] = f1.tolist()
    report['prec'] = prec.tolist()
    report['recall'] = recall.tolist()

    # safeMkdir(cfg.result_path)
    # print_log(cfg.log_path, report)
    # saveDict(report, join(cfg.result_path, 'report.json'))

    return report

from scipy.io import loadmat
class readRaizer:
    def __init__(self,file_path):
        self.file_path=file_path
        self.file=loadmat(self.file_path)['res_all']
        self.ava_videos=[self.file[7]]
        self.data={}
        self.read_from_file()

    def read_from_file(self):
        for video in self.ava_videos:
            video_id=video[0].item() # string
            obs_h2t_location= np.stack(video[1][0])[:,0,:] # hor to top location: x,y,w,h, 1000x4
            view_dir=np.stack(video[2][0]).squeeze() # view direction: float, 1000
            top_boxes=[]
            hor_boxes=[]
            all_boxes=video[3][0]
            for _i in range(all_boxes.shape[0]): # 1000
                two_boxes=all_boxes[_i][0]
                top_boxes.append(two_boxes[0]) # num x 4: x,y,w,h
                hor_boxes.append(two_boxes[1]) # num x 4: x,y,w,h
            self.data[video_id]={
                'vid':video_id,
                'obs_h2t_location':obs_h2t_location,
                'view_dir':view_dir,
                'top_boxes':top_boxes,
                'hor_boxes':hor_boxes
            }
        print(self.data)
        return self.data



if __name__ == '__main__':
    path='/HDDs/hdd1/gyy/dmha/MHA4dmha_0Res_ALL.mat'
    oneRazer=readRaizer(path)
    # cfg = Config('Distant')

    # cfg.device_list = "0,1"
    # cfg.use_multi_gpu = True
    # cfg.training_stage = 2
    # cfg.stage1_model_path = 'result/STAGE1_MODEL.pth'  # PATH OF THE BASE MODEL
    # cfg.train_backbone = False
    # cfg.test_before_train = True

    # cfg.image_size = 480, 720
    # cfg.out_size = 57, 87
    # cfg.num_boxes = 13
    # cfg.num_actions = 7
    # cfg.num_activities = 6
    # cfg.num_frames = 10
    # cfg.num_graph = 4
    # cfg.tau_sqrt = True

    # cfg.batch_size = 32
    # cfg.test_batch_size = 8
    # cfg.train_learning_rate = 1e-4
    # cfg.train_dropout_prob = 0.2
    # cfg.weight_decay = 1e-2
    # cfg.lr_plan = {}
    # cfg.max_epoch = 50

    # cfg.exp_note = 'Distant_stage2'
    # test_anns = distant_read_dataset(join(cfg.data_path, 'annotations'), cfg)
    # # print(test_anns)
    # # plot_confusion_matrix(cm=np.array([[1098, 1934, 807],
    # #                                    [604, 4392, 6233],
    # #                                    [162, 2362, 31760]]),
    # #                       save_path='./test.svg',
    # #                       normalize=False,
    # #                       target_names=['high', 'medium', 'low'],
    # #                       title="Confusion Matrix")
    # result = readDict(
    #     '/home/molijuly/myProjects/HIT/result/[Distant_stage2_stage2]<2020-10-30_01-57-01>/result_epoch0.json',
    #     key_is_int=True)
    # evaluateDistant(cfg, result, fast=False)
