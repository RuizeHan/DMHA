from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import cv2
import os
import _thread
import numpy as np
from tqdm import tqdm
import time
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import sys
CENTERNET_PATH = '../../'
sys.path.insert(0, CENTERNET_PATH)
from detectors.detector_factory import detector_factory
from opts import opts
from datasets.dataset_factory import get_dataset
import pycocotools.coco as coco
from collections import defaultdict
from multiprocessing import Process, Manager

m =  Manager()
public_dict_top = m.dict()
public_dict_hor = m.dict()

class DHNLoader(Dataset):
    def __init__(self, split='test', epoch='best', videos=None, frames=None, debug=1, wloc=1, multiprocess=1):
        print(split, ' ', 'wloc' if wloc else 'woloc')
        self.multiprocess = multiprocess
        self.split = split
        task = 'ctdet'
        # opt = opts()
        # self.model_dir =
        self.model_path_top = 'model_' + epoch + '_top.pth'
        self.model_path_hor = 'model_' + epoch + '_hor.pth'
        opt = opts().init('{} --load_model_top {} --load_model_hor {} --need_meta True'.format(task, self.model_path_top, self.model_path_hor, debug).split(' '))
        self.detector = detector_factory[opt.task](opt)
        # self.root_dir = '/HDDs/hdd1/gyy/dmha/virtual_data/Data/'

        self.annot_path_top = os.path.join(opt.data_dir, '', split + '_top' + '.json')
        self.annot_path_hor = os.path.join(opt.data_dir, '', split + '_hor' + '.json')
        self.coco_top = coco.COCO(self.annot_path_top)
        self.coco_hor = coco.COCO(self.annot_path_hor)
        self.images_top = self.coco_top.getImgIds()
        self.images_hor = self.coco_hor.getImgIds()
        self.videos = videos
        self.frames = frames
        self.debug = opt.vis or debug
        self.wloc = wloc

        self.img_dict_top, self.img_dict_hor = {}, {}

        self.tp = defaultdict(int)
        self.total = defaultdict(int)
        self.acc = defaultdict(int)
        self.eval_dict = {}
        a = 1

    def get_img_path_ls(self, dataset_dir):
        path_ls = os.listdir(dataset_dir)
        path_ls.sort(key = lambda x: int(x[:-4]))
        path_ls = [os.path.join(dataset_dir, x) for x in path_ls]
        return path_ls

    def load_img_top(self):
        for item in range(len(self.images_top)):
            img_id_top = self.images_top[item]
            img_id_hor = self.images_hor[item]
            file_name_top = self.coco_top.loadImgs(ids=[img_id_top])[0]['file_name']
            file_name_hor = self.coco_hor.loadImgs(ids=[img_id_hor])[0]['file_name']
            isnew = 'new' if file_name_top.split('/')[-5].endswith('new') else ''
            video_name = file_name_top.split('/')[-4]
            video_name = isnew + video_name
            frame_name = file_name_top.split('/')[-1].split('.')[0]
            if self.videos and video_name not in self.videos:
                continue
            if self.frames and frame_name not in self.frames:
                continue
            self.img_dict_top[img_id_top] = cv2.imread(file_name_top)
            # self.img_dict_hor[img_id_hor] = cv2.imread(file_name_hor)
            # public_dict_top[img_id_top] = cv2.imread(file_name_top)

    def load_img_hor(self):
        for item in range(len(self.images_top)):
            img_id_top = self.images_top[item]
            img_id_hor = self.images_hor[item]
            file_name_top = self.coco_top.loadImgs(ids=[img_id_top])[0]['file_name']
            file_name_hor = self.coco_hor.loadImgs(ids=[img_id_hor])[0]['file_name']
            isnew = 'new' if file_name_top.split('/')[-5].endswith('new') else ''
            video_name = file_name_top.split('/')[-4]
            video_name = isnew + video_name
            frame_name = file_name_top.split('/')[-1].split('.')[0]
            if self.videos and video_name not in self.videos:
                continue
            if self.frames and frame_name not in self.frames:
                continue
            # public_dict_hor[img_id_hor] = cv2.imread(file_name_hor)
            self.img_dict_hor[img_id_hor] = cv2.imread(file_name_hor)

    def load_img(self):
        for item in range(len(self.images_top)):
            img_id_top = self.images_top[item]
            img_id_hor = self.images_hor[item]
            file_name_top = self.coco_top.loadImgs(ids=[img_id_top])[0]['file_name']
            file_name_hor = self.coco_hor.loadImgs(ids=[img_id_hor])[0]['file_name']
            isnew = 'new' if file_name_top.split('/')[-5].endswith('new') else ''
            video_name = file_name_top.split('/')[-4]
            video_name = isnew + video_name
            if self.videos and video_name not in self.videos:
                continue
            self.img_dict_top[img_id_top] = cv2.imread(file_name_top)
            self.img_dict_hor[img_id_hor] = cv2.imread(file_name_hor)
            # public_dict_top[img_id_top] = cv2.imread(file_name_top)
            # public_dict_hor[img_id_hor] = cv2.imread(file_name_hor)

    def __len__(self):
        return len(self.images_top)

    def cal(self, pred, gt, video_name):
        self.total[video_name] += 1
        if min(pred + 360 - gt, gt + 360 - pred, abs(gt - pred)) < 20:
            self.tp[video_name] += 1
        self.acc[video_name] = self.tp[video_name] / self.total[video_name]
        print(video_name, self.acc[video_name])
        self.eval_dict[video_name] = self.acc[video_name]

    # @profile
    def __getitem__(self, item):

        # top_info = self.info_top[item]
        img_id_top = self.images_top[item]
        file_name_top = self.coco_top.loadImgs(ids=[img_id_top])[0]['file_name']

        img_id_hor = self.images_hor[item]
        # print(file_name_top)
        isnew = 'new' if file_name_top.split('/')[-5].endswith('new') else ''
        video_name = isnew + file_name_top.split('/')[-4]
        frame_name = file_name_top.split('/')[-1].split('.')[0]

        if self.videos and video_name not in self.videos:
            return {}
        if self.frames and frame_name not in self.frames:
            return {}

        # hor_info = self.info_hor[item]

        file_name_hor = self.coco_hor.loadImgs(ids=[img_id_hor])[0]['file_name']


        if self.multiprocess:
            try:
                self.img_dict_hor[img_id_hor]
            except:
                print('sleeping...')
                time.sleep(0.5)

            # img_top, img_hor = public_dict_top[img_id_top], public_dict_hor[img_id_hor]
            # del public_dict_top[img_id_top], public_dict_hor[img_id_hor]
            img_top, img_hor = self.img_dict_top[img_id_top], self.img_dict_hor[img_id_hor]
            del self.img_dict_top[img_id_top], self.img_dict_hor[img_id_hor]
        else:
            img_top = cv2.imread(file_name_top)
            img_hor = cv2.imread(file_name_hor)

        ann_ids_top = self.coco_top.getAnnIds(imgIds=[img_id_top])
        ann_ids_hor = self.coco_hor.getAnnIds(imgIds=[img_id_hor])
        anns_top = self.coco_top.loadAnns(ids=ann_ids_top)
        anns_hor = self.coco_hor.loadAnns(ids=ann_ids_hor)


        dets_top_gt = [i['bbox'] for i in anns_top]
        id_top_gt = [i['name_id'] for i in anns_top]
        id_ls = [i['id'] for i in anns_top]
        location_id = self.coco_top.loadImgs(ids=[img_id_top])[0]['observer']
        for i, idx in enumerate(id_ls):
            if idx == location_id:
                location_gt = id_top_gt[i]
        dets_location_id =  id_top_gt.index(location_gt)
        dets_location = dets_top_gt[dets_location_id]

        if self.wloc:
            ret_dict = self.detector.run(img_top, img_hor, dets_location)
        else:
            ret_dict = self.detector.run(img_top, img_hor, None)

        ret_dict['dets_top_gt'] = dets_top_gt
        ret_dict['id_top_gt'] = id_top_gt
        ret_dict['location_gt'] = location_gt


        ret_dict['dets_hor_gt'] = [i['bbox'] for i in anns_hor]
        ret_dict['id_hor_gt'] = [i['name_id'] for i in anns_hor]

        ret_dict['frame'] = video_name + '_' + frame_name
        angle_gt = self.coco_top.loadImgs(ids=[img_id_top])[0]['angle']
        ret_dict['angle_gt'] =  (angle_gt - 45 + 360) % 360


        for box, idx in zip(ret_dict['dets_hor_gt'][::-1], ret_dict['id_hor_gt'][::-1]):
            if box == [0, 0, 0, 0]:
                ret_dict['dets_hor_gt'].remove(box)
                ret_dict['id_hor_gt'].remove(idx)
        # self.cal(ret_dict['angle_pred'], ret_dict['angle_gt'], video_name)

        if self.debug:
            loc = ret_dict['location_pred']
            ret_dict['img_top'] = img_top
            ret_dict['img_hor'] = img_hor
            self.show_img(ret_dict, 'top', 'rgb', loc)
            self.show_img(ret_dict, 'hor', 'rgb', loc)


        return ret_dict

    def show_img(self, res, view, type, loc):
        img = None
        bboxs_pred = None
        bboxs_gt = None
        dir = '/home/ganyiyang/document/dmha/v0/output'

        if type == 'rgb':
            if view == 'hor':
                bboxs_pred = res['dets_hor_ori']
                bboxs_gt = res['dets_hor_gt']
                img = res['img_hor']
            elif view == 'top':
                bboxs_pred = res['dets_top_ori']
                bboxs_gt = res['dets_top_gt']
                img = res['img_top']
            for i, bbox_pred in enumerate(bboxs_pred):
                cv2.rectangle(img, (int(bbox_pred[0]), int(bbox_pred[1])), (int(bbox_pred[2]), int(bbox_pred[3])),
                              (255, 0, 0), 1)
            # for i, bbox_pred in enumerate(bboxs_pred):
            #     if i == loc:
            #         cv2.rectangle(img, (int(bbox_pred[0]), int(bbox_pred[1])), (int(bbox_pred[2]), int(bbox_pred[3])),
            #                       (255, 0, 0), 2)
            #     else:
            #         cv2.rectangle(img, (int(bbox_pred[0]), int(bbox_pred[1])), (int(bbox_pred[2]), int(bbox_pred[3])),
            #                     (0, 255, 255), 2)
            # for bbox_gt in bboxs_gt:
            #     cv2.rectangle(img, (bbox_gt[0], bbox_gt[1]), (bbox_gt[0] + bbox_gt[2], bbox_gt[1] + bbox_gt[3]), (0, 0, 255), 2)

        elif type == 'hm':
            if view == 'hor':
                img = res['hm_hor_pred'][0].transpose(1, 2, 0) * 255
            elif view == 'top':
                img = res['hm_top_pred'][0].transpose(1, 2, 0) * 255
        view = '1' if view == 'top' else '2'
        cv2.imwrite(os.path.join(dir, view + '.png'), img)



def main_fun(loader):

    save_path = '/HDDs/hdd1/gyy/dmha/dicts_rank'
    # save_path = os.path.join(save_path, '{}_{}_woinv.npy'.format(loader.split, 'wloc' if loader.wloc else 'woloc'))
    save_path = os.path.join(save_path, '{}_{}_woinv.npy'.format('cross', 'wloc' if loader.wloc else 'woloc'))
    inf_loader = loader

    # inf_loader = DataLoader(
    #     loader,
    #     num_workers=1,
    #     pin_memory=True,
    #     drop_last=False
    # )

    res = {}
    for i, data in tqdm(enumerate(inf_loader), total=len(inf_loader)):
        # if i > 100:
        #     break
        res[i] = data

    np.save(save_path, res)
    print(loader.eval_dict)


if __name__ == '__main__':
    for split in ['test']:
        for wloc in [1]:
            loader = DHNLoader(split=split, wloc=wloc)
            _thread.start_new_thread(loader.load_img_top, ())
            _thread.start_new_thread(loader.load_img_hor, ())
            # p1= Process(target=loader.load_img_top, args=())
            # p2 = Process(target=loader.load_img_hor, args=())
            # p1.start()
            # p2.start()
            main_fun(loader)