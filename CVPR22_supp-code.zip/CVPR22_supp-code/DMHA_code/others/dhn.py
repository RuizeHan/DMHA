from torch.utils.data import Dataset
from torch.utils.data import DataLoader


import json
import os
import torch
import numpy as np
from tqdm import tqdm
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import sys
CENTERNET_PATH = '../../'
sys.path.insert(0, CENTERNET_PATH)
import torch.utils.data as data

def iou(box1, box2):
    '''  
    box1:[x1, y1, x2,y2]
    box2:[x1, y1, w,h]
    '''
    box2[2]=box2[0]+box2[2]
    box2[3]=box2[1]+box2[3]
    ctr_1x = (box1[0] + box1[2]) // 2
    ctr_2x = (box2[0] + box2[2]) // 2
    ctr_1y = (box1[1] + box1[3]) // 2
    ctr_2y = (box2[1] + box2[3]) // 2
    iou = np.sqrt(np.square(ctr_1x - ctr_2x) + np.square((ctr_1y - ctr_2y)))
    return iou

class DHNDataset(data.Dataset):
    def __init__(self,opt,split):
      super(DHNDataset,self).__init__()
      self.opt=opt
      task = 'dhn'
      if split=='train':
            # self.numpy_file = '/home/ganyiyang/res.npy' 
            self.numpy_file='/HDDs/hdd1/gyy/dmha/dicts/train_wloc_woinv.npy'
      else:
            # self.numpy_file = '/home/ganyiyang/res.npy' 
            self.numpy_file = '/HDDs/hdd1/gyy/dmha/dicts/test_wloc_woinv.npy'
      # self.root_dir = '/HDDs/hdd1/gyy/dmha/virtual_data/Data/'
      # self.dateset_dir_top = os.path.join(self.root_dir, 'top_video')
      # self.dataset_dir_hor = os.path.join(self.root_dir, 'hor1_video')
      
      self.batch_data=np.load(self.numpy_file,allow_pickle=True).item() # A dict, contain dicts of many frames.
      # Each dict of one frame contains many keys: 'dets_top', 'hm_top', 'angle_top', 'dets_hor', 'hm_hor', 'annos_box_top', 'annos_id_top', 'annos_box_hor', 'annos_id_hor'
      self.fids=self.batch_data.keys()

    def __len__(self):
        return len(self.fids)
  
    def _to_float(self, x):
      return float("{:.2f}".format(x))
  
    def convert_eval_format(self, all_bboxes):
      # import pdb; pdb.set_trace()
      detections = []
      for image_id in all_bboxes:
        for cls_ind in all_bboxes[image_id]:
          category_id = self._valid_ids[cls_ind - 1]
          for bbox in all_bboxes[image_id][cls_ind]:
            bbox[2] -= bbox[0]
            bbox[3] -= bbox[1]
            score = bbox[4]
            bbox_out  = list(map(self._to_float, bbox[0:4]))
  
            detection = {
                "image_id": int(image_id),
                "category_id": int(category_id),
                "bbox": bbox_out,
                "score": float("{:.2f}".format(score))
            }
            if len(bbox) > 5:
                extreme_points = list(map(self._to_float, bbox[5:13]))
                detection["extreme_points"] = extreme_points
            detections.append(detection)
      return detections
  
  
    def save_results(self, results, save_dir):
      json.dump(self.convert_eval_format(results), 
                  open('{}/results.json'.format(save_dir), 'w'))
    
    def run_eval(self, results, save_dir):
      return
  


class DHNSampler(data.Dataset):
  def __getitem__(self, item):
    ret_dict=self.batch_data[item]
    for key in ret_dict.keys():
          if type(ret_dict[key])==np.ndarray:
                ret_dict[key]=torch.from_numpy(ret_dict[key])
          elif type(ret_dict[key])==list:
                ret_dict[key]=torch.Tensor(ret_dict[key])
    return ret_dict

import math
def divide_virtual_train_test(npy_path):
  ori_data=np.load(npy_path,allow_pickle=True).item()
  a = set()
  num=len(ori_data.keys())
  available_fids=[]
  # print('original keys:')
  # print(ori_data.keys())
  # Filter useless
  print('--------All num: %d-------'%num)
  print('----------- Filtering useless-----------')
  for i in range(num):
    if ori_data[i]['frame'] == '41_1':
        a = 1
    index_gt=ori_data[i]['id_top_gt'].index(ori_data[i]['location_gt'])
    bbox_pred=ori_data[i]['dets_top_ori'][ori_data[i]['location_pred']]
    bbox_gt=ori_data[i]['dets_top_gt'][index_gt]
    IOU=iou(bbox_pred,bbox_gt)
    obs_correct=IOU>0.5
    angle_correct=min(ori_data[i]['angle_pred'] + 360 - ori_data[i]['angle_gt'], ori_data[i]['angle_gt'] + 360 - ori_data[i]['angle_pred'], abs(ori_data[i]['angle_gt'] - ori_data[i]['angle_pred'])) < 20
    # if not obs_correct and angle_correct:
    #     a = 1
    if obs_correct&angle_correct:
      available_fids.append(i)
    # if not obs_correct:
      # print(IOU)
  a = [int(i) for i in a]
  a.sort()
  print(a)
  ava_num=len(available_fids)
  print('----------Over, available frame num: %d--------'%ava_num)
  # Divide into train set and test set
  train_num=ava_num//2
  test_num=ava_num-ava_num//2
  train_dict={}
  test_dict={}
  choice=np.random.choice(ava_num,ava_num,replace=False)
  for i in range(train_num):
    train_dict[i]=ori_data[available_fids[choice[i]]]
  for i in range(train_num,train_num+test_num):
    test_dict[i]=ori_data[available_fids[choice[i]]]
  # Save to disk
  with open('/HDDs/hdd1/gyy/dmha/dicts/train.npy', 'wb') as f:
    np.save(f,train_dict)
  with open('/HDDs/hdd1/gyy/dmha/dicts/test.npy', 'wb') as f:
    np.save(f,test_dict)

if __name__ == '__main__':
    # loader = DHNDataset()
    save_path = '/HDDs/hdd1/gyy/dmha/dicts'
    save_path1 = os.path.join(save_path, 'test_wloc_woinv.npy')
    save_path2 = os.path.join(save_path, 'train_wloc_woinv.npy')
    for save_path in [save_path1, save_path2]:
        divide_virtual_train_test(save_path)
    # res = {}
    # for i, data in tqdm(enumerate(loader), total=len(loader)):
    #     res[i] = data

    # np.save(save_path, res)