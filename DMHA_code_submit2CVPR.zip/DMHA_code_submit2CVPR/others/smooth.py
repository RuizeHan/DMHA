from scipy import io
import numpy as np
import os
from collections import defaultdict
import math
import matplotlib.pyplot as plt

class Smooth():
    def __init__(self, file=None, video=[]):
        self.file = file
        self.res = np.load(file, allow_pickle=True).item()
        self.res_by_video = defaultdict(list)
        self.video_ls = video if len(video) else self.res_by_video
        for frame_i in self.res:
            if self.res[frame_i]:
                self.res_by_video[self.res[frame_i]['frame'].split('_')[0]].append(self.res[frame_i])
        del self.res
        # for video_i in self.res_by_video:
        #     self.res_by_video[video_i].sort(key=lambda x: int(x['frame'].split('_')[1]))
        self.angle_acc_dict = {}
        self.avg_acc = 0
        self.angle_acc_dict_smooth = {}
        self.avg_acc_smooth = 0

        self.angle_eval_acc = 20
        self.angle_smooth_times = 0
        self.short_filter_size = 6
        self.long_filter_size = 50
        self.filter_error = 10


        self.base()
        self.save_res(self.res_by_video)


        self.avg_acc = sum([float(self.angle_acc_dict[i]) for i in self.angle_acc_dict]) / len(self.angle_acc_dict)
        self.avg_acc_smooth = sum([float(self.angle_acc_dict_smooth[i]) for i in self.angle_acc_dict_smooth]) / len(self.angle_acc_dict)
        print(self.angle_acc_dict)
        print(self.avg_acc)
        print(self.angle_acc_dict_smooth)
        print(self.avg_acc_smooth)
        a = 1

    def vis(self, pred, gt=None):
        x1 = np.arange(0, len(pred))
        y1 = pred
        plt.plot(x1, y1, label="pred")
        plt.legend()
        plt.savefig('/home/ganyiyang/document/dmha/v0/output/curve.png')


    def base(self):
        for video_i in self.video_ls:
            if video_i in ['49', '50']:
                continue
            video_info = self.res_by_video[video_i]
            video_angle_pred_ls = []
            video_angle_gt_ls = []
            for frame_i, frame_info in enumerate(video_info):
                angle_pred = frame_info['angle_pred']
                angle_gt = frame_info['angle_gt']
                video_angle_pred_ls.append(angle_pred)
                video_angle_gt_ls.append(angle_gt)

                location_pred = frame_info['location_pred']
                location_gt = frame_info['location_gt']

            video_angle_pred_ls_smooth = self.angle_smooth_legend(video_angle_pred_ls[:])
            # self.vis(video_angle_pred_ls)
            self.angle_acc_dict[video_i] = '{:.3f}'.format(self.angle_acc(video_angle_pred_ls, video_angle_gt_ls))
            self.angle_acc_dict_smooth[video_i] = '{:.3f}'.format(self.angle_acc(video_angle_pred_ls_smooth, video_angle_gt_ls))
            for frame_i, frame_info in enumerate(video_info):
                crop_line_before = (frame_info['angle_pred'] / 360) * 512
                angle_gt_tmp = frame_info['angle_gt']
                angle_pred_tmp = frame_info['angle_pred']
                frame_info['angle_pred'] = video_angle_pred_ls_smooth[frame_i]
                angle_gt_modify_tmp = frame_info['angle_pred']
                crop_line_after = (frame_info['angle_pred'] / 360) * 512
                crop_line_dis = (crop_line_after - crop_line_before + 512) % 512
                frame_info['dets_top_pred'][:, 0] = (frame_info['dets_top_pred'][:, 0]- crop_line_dis + 512) % 512
                a = 1





    def angle_acc(self, pred_ls, gt_ls):
        res = [1 if self.calc_angle_minus(x, y) < self.angle_eval_acc else 0 for x, y in zip(pred_ls, gt_ls)]
        return sum(res) / len(res)

    def angle_smooth_legend(self, pred_ls):

        for _ in range(self.angle_smooth_times):
            if self.short_filter_size:
                self.angle_smooth(pred_ls, self.short_filter_size)
            if self.long_filter_size:
                self.angle_smooth(pred_ls, self.long_filter_size)


        return pred_ls

    def angle_smooth(self, pred_ls, filter_size=20):
        video_length = len(pred_ls)
        for i in range(filter_size // 2, video_length - filter_size // 2):
            l = pred_ls[i - filter_size // 2: i]
            avg1 = self.calc_angles_mean(l)
            r = pred_ls[i: i + filter_size // 2]
            avg2 = self.calc_angles_mean(r)

            # if self.calc_angle_minus(avg1, avg2) < self.filter_error:
            #     pred_ls[i] = self.calc_angles_mean([avg1, avg2])

            if self.calc_angle_minus(avg1, pred_ls[i]) > self.filter_error and self.calc_angle_minus(avg2, pred_ls[i]) > self.filter_error:
                pred_ls[i] = self.calc_angles_mean([avg1, avg2])
        return pred_ls

    def calc_angles_mean(self, data_list):
        m_sin, m_cos = self.calc_mean_sin_cos(data_list)

        mean_angle = math.atan(m_sin / m_cos) * (180 / math.pi)  # calculate mean angle
        if (m_cos >= 0):
            mean_angle = mean_angle
        elif (m_cos < 0):
            mean_angle = mean_angle + 180
        if mean_angle < 0:
            mean_angle = 360 + mean_angle  # (-pi/2, 0) -> +
        return mean_angle

    def calc_mean_sin_cos(self, data_list):
        m_sin = 0
        m_cos = 0
        for data_elmt in data_list:
            m_sin += math.sin(math.radians(data_elmt))
            m_cos += math.cos(math.radians(data_elmt))
        m_sin /= len(data_list)  # average of list sin
        m_cos /= len(data_list)
        return m_sin, m_cos

    def calc_angle_minus(self, a, b):
        return min(a + 360 - b, b + 360 - a, abs(a - b))

    def save_res(self, dict):
        ret = {}
        i = 0
        for video_i in self.video_ls:
            if video_i in ['49', '50']:
                continue
            video_info = self.res_by_video[video_i]
            for frame_i, frame_info in enumerate(video_info):
                ret[i] = frame_info
                i += 1
        save_dir = self.file[:-4] + '_wo4950.npy'
        np.save(save_dir, ret)



if __name__ == '__main__':
    save_dir = '/HDDs/hdd1/gyy/dmha/cnn_real_rank'
    input_ls = ['cross_wloc_woinv.npy']
    for input_npy in input_ls:
        file = os.path.join(save_dir, input_npy)
        s = Smooth(file=file)


