def draw_curves(a, b):
    import cv2
    import matplotlib.pyplot as plt
    import numpy as np
    plt.close('all')
    curve1 = a[0].detach().cpu().numpy()
    curve2 = b[0].detach().cpu().numpy()

    x1 = np.arange(0, curve1.shape[-1])
    x2 = np.arange(0, curve2.shape[-1])
    y1 = curve1
    y2 = curve2
    plt.plot(x1, y1 ,label="pred")
    plt.plot(x2, y2 ,label="gt")
    plt.legend()
    plt.savefig('/home/ganyiyang/document/dmha/v0/output/curve.png')

# draw_curves(pred, gt)
draw_curves(img_hor_compress[0][0], img_360_compress[0][0])
# draw_curves(hm_hor[0][0], cropped_top[0][0])

def draw_tensor_img(img):
    img = img[0].detach().cpu().numpy().transpose(1, 2, 0)*255
    dir = '/home/ganyiyang/document/dmha/v0/output'
    import cv2, os
    cv2.imwrite(os.path.join(dir, '9.png'), img)
draw_tensor_img(img_360)
# draw_tensor_img(hm)

def base_trainer_debugger():
    dir1 = '/home/ganyiyang/document/dmha/v0/output'
    import cv2, os
    cv2.imwrite(os.path.join(dir1, 'ori_top.png'), batch_top['img'][0].detach().cpu().numpy())
    cv2.imwrite(os.path.join(dir1, 'ori_hor.png'), batch_hor['img'][0].detach().cpu().numpy())
    cv2.imwrite(os.path.join(dir1, '360.png'), res['360'][0].detach().cpu().permute(1, 2, 0).numpy() * 255)
    cv2.imwrite(os.path.join(dir1, 'hm_top.png'), res['top_hm'][0].detach().cpu().permute(1, 2, 0).numpy() * 255)
    cv2.imwrite(os.path.join(dir1, 'hm_hor.png'), res['hor_hm'][0].detach().cpu().permute(1, 2, 0).numpy() * 255)

def draw_1d_map(img):
    img = img.expand(1, 1, 128, img.shape[-1])[0].detach().cpu().numpy().transpose(1, 2, 0)*255
    dir = '/home/ganyiyang/document/dmha/v0/output'
    import cv2, os
    cv2.imwrite(os.path.join(dir, '2.png'), img)
draw_1d_map(img_360_compress[0])

def draw_np_map(img):
    img = img[0].transpose(1, 2, 0) * 255
    dir = '/home/ganyiyang/document/dmha/v0/output'
    import cv2, os
    cv2.imwrite(os.path.join(dir, 'hm.png'), img)
draw_np_map(ret_dict['hm_top_pred'])

def draw_rgb_img(img):
    dir = '/home/ganyiyang/document/dmha/v0/output'
    import cv2, os
    cv2.imwrite(os.path.join(dir, 'rgb.png'), img)
draw_rgb_img(img_top)