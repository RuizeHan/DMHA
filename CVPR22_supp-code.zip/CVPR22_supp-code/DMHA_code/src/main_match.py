from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'

import torch
import torch.utils.data
from opts import opts
from models.model import create_model, load_model, save_model
from models.data_parallel import DataParallel
from logger import Logger
from datasets.dataset_factory import get_dataset
from trains.train_factory import train_factory
from itertools import chain
import warnings
# warnings.filterwarnings("ignore")
from torch.utils.tensorboard import SummaryWriter
# tensorboard --logdir=runs

def main(opt):
  torch.manual_seed(opt.seed)
  torch.backends.cudnn.benchmark = not opt.not_cuda_benchmark and not opt.test
  Dataset = get_dataset('dhn', 'dhn')
  print(opt)

  logger = Logger(opt)

  # # os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpus_str
  opt.device = torch.device('cuda' if opt.gpus[0] >= 0 else 'cpu')
  
  print('Creating model...')
  model_top = create_model(opt.arch, 0,0)
  model_hor = create_model(opt.arch, 0,0)
  optimizer = torch.optim.Adam(chain(model_hor.parameters(), model_top.parameters()), opt.lr)
  # optimizer_hor = torch.optim.Adam(model_hor.parameters(), opt.lr)
  start_epoch = 0
  if opt.load_model != '':
    model_top, optimizer_top, start_epoch = load_model(model_top, opt.load_model, optimizer, opt.resume, opt.lr, opt.lr_step)
    model_hor, optimizer_hor, start_epoch = load_model(model_hor, opt.load_model, optimizer, opt.resume, opt.lr, opt.lr_step)
  
  if opt.test:
    if opt.model_path!='':
      model_top, optimizer_top, start_epoch = load_model(model_top, opt.model_path+'model_best_top.pth', optimizer, opt.resume, opt.lr, opt.lr_step)
      model_hor, optimizer_hor, start_epoch = load_model(model_hor, opt.model_path+'model_best_hor.pth', optimizer, opt.resume, opt.lr, opt.lr_step)
    else:
      model_top, optimizer_top, start_epoch = load_model(model_top, './exp/dhn/default/model_best_top.pth', optimizer, opt.resume, opt.lr, opt.lr_step)
      model_hor, optimizer_hor, start_epoch = load_model(model_hor, './exp/dhn/default/model_best_hor.pth', optimizer, opt.resume, opt.lr, opt.lr_step)

  Trainer = train_factory[opt.task]
  trainer = Trainer(opt, model_top, model_hor, optimizer)
  trainer.set_device(opt.gpus, opt.chunk_sizes, opt.device)
  # print(opt.device)
  # print(os.environ['CUDA_VISIBLE_DEVICES'])

  # Inference
  print('Setting up data...')
  val_loader = torch.utils.data.DataLoader(
      Dataset(opt, 'test'),
      batch_size=1, 
      shuffle=False,
      num_workers=0,
      pin_memory=True
  )
  ops_dict={
          'main':opt.save_dir,
          'MHA':os.path.join(opt.save_dir,'MHA'),
          'dim2':os.path.join(opt.save_dir,'union'),
          'dim2r':os.path.join(opt.save_dir,'unionr'),
          'wox':os.path.join(opt.save_dir,'wox'),
          'woy':os.path.join(opt.save_dir,'woy'),
          "wdepth":os.path.join(opt.save_dir,'wdepth'),
          "wbottom":os.path.join(opt.save_dir,'wbottom'),
          'woxr':os.path.join(opt.save_dir,'woxr'),
          'woyr':os.path.join(opt.save_dir,'woyr'),
          "woyrr":os.path.join(opt.save_dir,'woyrr'),
          "wdepthr":os.path.join(opt.save_dir,'wdepthr'),
          "wbottomr":os.path.join(opt.save_dir,'wbottomr'),
          'unionc':os.path.join(opt.save_dir,'unionc'),
        }
  if not os.path.exists(ops_dict[opt.ours]):
    os.mkdir(ops_dict[opt.ours])
  if opt.test:
    if opt.result_path!='':
      preds=torch.load(opt.result_path)
    else:
      _, preds = trainer.val(0, val_loader)
    val_loader.dataset.run_eval(preds, ops_dict[opt.ours])
    return

# DataLode
  train_loader = torch.utils.data.DataLoader(
      Dataset(opt, 'train'),
      batch_size=opt.batch_size,
      shuffle=False,
      num_workers=0,
      pin_memory=True,
      drop_last=False
  )

  # Training Stage
  print('Starting training...')
  best = 1e10
  writer = SummaryWriter()
  for epoch in range(start_epoch + 1, opt.num_epochs + 1):
    mark = epoch if opt.save_all else 'last'
    log_dict_train, _ = trainer.train(epoch, train_loader)
    # print(log_dict_train)

    logger.write('epoch: {} |'.format(epoch))
    for k, v in log_dict_train.items():
      if k in ['loss', 'loss_x', 'loss_y']:
        writer.add_scalars(k, {k:v.avg}, epoch)
        logger.scalar_summary('train_{}'.format(k), v.avg, epoch)
        logger.write('{} {:8f} | '.format(k, v.avg))
    if opt.val_intervals > 0 and epoch % opt.val_intervals == 0:
      save_model(os.path.join(ops_dict[opt.ours], 'model_top_{}.pth'.format(mark)),
                 epoch, model_top, optimizer)
      save_model(os.path.join(ops_dict[opt.ours], 'model_hor_{}.pth'.format(mark)),
                 epoch, model_hor, optimizer)
      with torch.no_grad():
        log_dict_val, preds = trainer.val(epoch, val_loader)
      for k, v in log_dict_val.items():
        try:
          logger.scalar_summary('val_{}'.format(k), v.avg, epoch)
          logger.write('{} {:8f} | '.format(k, v.avg))
        except:
          if not hasattr(v,'avg'):
                logger.scalar_summary('val_{}'.format(k), v, epoch)
                logger.write('{} {:8f} | '.format(k, v))
              
        
      if log_dict_val[opt.metric].avg < best:
        best = log_dict_val[opt.metric].avg
        save_model(os.path.join(ops_dict[opt.ours], 'model_best_top.pth'),
                   epoch, model_top)
        save_model(os.path.join(ops_dict[opt.ours], 'model_best_hor.pth'),
                   epoch, model_hor)
        if not os.path.exists(ops_dict[opt.ours]):
          os.mkdir(ops_dict[opt.ours])
        torch.save(preds,os.path.join(ops_dict[opt.ours], 'results_best.pth.tar'))
        val_loader.dataset.run_eval(preds, ops_dict[opt.ours])
      else:
        save_model(os.path.join(ops_dict[opt.ours], 'model_last_top.pth'),
                  epoch, model_top, optimizer)
        save_model(os.path.join(ops_dict[opt.ours], 'model_last_hor.pth'),
                  epoch, model_hor, optimizer)
    logger.write('\n')
    if epoch in opt.lr_step:
      save_model(os.path.join(ops_dict[opt.ours], 'model_top_{}.pth'.format(epoch)),
                 epoch, model_top, optimizer)
      save_model(os.path.join(ops_dict[opt.ours], 'model_hor_{}.pth'.format(epoch)),
                 epoch, model_hor, optimizer)
      lr = opt.lr * (0.1 ** (opt.lr_step.index(epoch) + 1))
      print('Drop LR to', lr)
      for param_group in optimizer.param_groups:
          param_group['lr'] = lr
  # val_loader.dataset.run_eval(preds, ops_dict[opt.ours])
  logger.close()

if __name__ == '__main__':
  opt = opts().parse()
  # opt.init('{} --batch_size {} --arch {}'.format('dhn',1, 'DHN'))
  main(opt)